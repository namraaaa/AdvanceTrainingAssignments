package Abstract;

public abstract class Instrument {
	public abstract void play();
}

