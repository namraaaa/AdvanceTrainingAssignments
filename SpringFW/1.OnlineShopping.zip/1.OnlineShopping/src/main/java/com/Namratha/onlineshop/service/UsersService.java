package com.Namratha.onlineshop.service;

import com.Namratha.onlineshop.model.Users;

public interface UsersService {

	public void addUsers(Users users);
	
	Users findUserByusername(String username);
}
